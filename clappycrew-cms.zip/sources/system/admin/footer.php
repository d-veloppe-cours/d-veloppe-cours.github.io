</body>

<footer>
    <p> Propulsé par <a href="https://clappycrew.com">ClappyCrew</a> © 2018 - <?php echo date("Y") ?></p>
</footer>