<?php

header('Location: https://host.clappycrew.com/');
exit();