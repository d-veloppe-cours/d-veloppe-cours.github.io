<?php

header('Location: https://opensource.clappycrew.com/');
exit();