</body>

<footer>
    <p> Propulsé par <a href="clappycrew.com">ClappyCrew © 2018 - <?php echo date("Y") ?> </p>
</footer>
