<section class="home">
    <br>
    <center>
        <h1 class="animate__animated animate__backInUp">BIENVENUE SUR TON SITE</h1>
    </center>
</section>
