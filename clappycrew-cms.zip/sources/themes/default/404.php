<section class="home">

    <center>
        <h2 class="animate__animated animate__headShake" style="padding-top: 15%;"> ERREUR 404 ~ Cette page est introuvalbe ! </h2>
    </center>

</section>
